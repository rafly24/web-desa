<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
  
      <div class="section-title">
        <h2><?php echo e($sejarah->judul); ?></h2>
      </div>
  
      <div class="row">
        <div class="col-lg-10 mx-auto p-3">
            <?php echo $sejarah->body; ?>

        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/sejarah/index.blade.php ENDPATH**/ ?>
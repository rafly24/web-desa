<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Edit Visi & Misi</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/visi-misi" type="button" class="btn btn-warning float-end" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <div class="row">
               <form method="POST" action="/admin/visi-misi/<?php echo e($visiMisi->id); ?>">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>

                    <div class="col">
                        <div class="mb-3">
                            <label for="visi" class="form-label">Visi <span style="color: red">*</span></label>
                            <textarea class="form-control" id="visi" name="visi" rows="5"><?php echo e(old('visi', $visiMisi->visi)); ?></textarea>
                            <?php $__errorArgs = ['visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="misi" class="form-label">Deskripsi <span style="color: red">*</span></label>
                            <textarea class="form-control" id="visi" name="misi" rows="5"><?php echo e(old('misi', $visiMisi->misi)); ?></textarea>
                            <?php $__errorArgs = ['misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary m-1 float-end">Update</button>
               </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/visi-misi/edit.blade.php ENDPATH**/ ?>
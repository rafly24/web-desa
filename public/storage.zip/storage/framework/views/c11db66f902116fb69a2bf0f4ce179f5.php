<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-6 footer-info">
            <img src="<?php echo e(asset('storage/' . $logo->logo)); ?>" class="mb-2" alt="Logo" width="250">
            <h3><?php echo e($nm_desa); ?></h3>
            <p>
              Kecamatan <?php echo e($kecamatan); ?>, Kabupaten <?php echo e($kabupaten); ?>, <br> Provinsi <?php echo e($provinsi); ?>, Kode Pos <?php echo e($kode_pos); ?><br><br>
              <strong>Nomor HP :</strong> <?php echo e($no_hp); ?><br>
              <strong>Email :</strong> <?php echo e($email); ?><br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Menu</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="/">Beranda</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/berita">Berita</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/umkm">Umkm</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/data-desa">Data Desa</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/kontak">Kontak Kami</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Profil Desa</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="/wilayah">Wilayah</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/sejarah">Sejarah</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/visi-misi">Visi & Misi</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/perangkat-desa">Perangkat Desa</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/peta-desa">Peta Desa</a></li>
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>2025</span></strong>. || Repost By : <a href="https://www.youtube.com/@kaseps8304/videos">Kasep_Code</a>
      </div>
    </div>
  </footer><!-- End Footer --><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/partials/footer.blade.php ENDPATH**/ ?>
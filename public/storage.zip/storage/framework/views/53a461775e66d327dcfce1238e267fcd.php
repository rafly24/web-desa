<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="container">
            <div class="section-title">
                <h2>Anggaran Desa / APBDES</h2>
            </div>
            <div class="row">
                <?php $__currentLoopData = $anggarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-3" data-aos="fade-up">
                        <div class="count-box news-card">
                            <div class="card">
                                <img src="<?php echo e(asset('storage/' . $anggaran->gambar)); ?>" alt="gambar anggaran"
                                    class="card-img-top">
                                <div class="card-body">
                                    <h5 class="card-title"><b><?php echo e($anggaran->judul); ?></b></h5>

                                </div>

                                <a class="btn btn-primary mx-3 mb-3" href="/apbdesa/<?php echo e($anggaran->slug); ?>" role="button"><i
                                        class="bi bi-eye"></i>&nbsp; Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="paginate my-3" style="text-align: center">
                <?php echo e($anggarans->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/apbdesa/index.blade.php ENDPATH**/ ?>
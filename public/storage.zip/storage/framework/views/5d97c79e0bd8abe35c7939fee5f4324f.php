<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Data Umkm Desa</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/admin/umkm/create" type="button" class="btn btn-warning float-end">Tambah Produk</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="table-responsive">
                    <table id="table_id" class="table display">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Foto</th>
                                <th>Produk</th>
                                <th>Harga</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img src="<?php echo e(asset('storage/' . $umkm->foto)); ?>" alt="Foto UMKM" class="img-fluid" style="max-height: 200px; max-width: 200px"></td>
                                <td><?php echo e($umkm->produk); ?></td>
                                <td><span class="badge text-bg-primary">Rp. <?php echo e($umkm->harga); ?></span></td>
                                <td>
                                    <a href="/umkm/<?php echo e($umkm->slug); ?>" type="button" target="_blank" class="btn btn-success mb-1"><i class="ti ti-eye-check"></i></a>
                                    <a href="/admin/umkm/<?php echo e($umkm->id); ?>/edit" type="button" class="btn btn-warning mb-1"><i class="ti ti-edit"></i></a>
                                    <form id="<?php echo e($umkm->id); ?>" action="/admin/umkm/<?php echo e($umkm->id); ?>" method="POST" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger swal-confirm mb-1" data-form="<?php echo e($umkm->id); ?>"><i class="ti ti-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>                        
                    </table>
                </div>
            </div>
        </div>
      </div>
    </div>
</div>

<script>
    $(document).ready( function () {
        $('#table_id').DataTable();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/umkm/index.blade.php ENDPATH**/ ?>
<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Website Portal Desa Cibuni Copyright 2025</p> Repost By : <a href="https://www.youtube.com/@kaseps8304/videos">Kasep_Code</a>
  </div><?php /**PATH C:\xampp\htdocs\portal-desa-master\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>